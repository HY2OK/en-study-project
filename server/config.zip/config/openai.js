export const API_KEY = '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';
