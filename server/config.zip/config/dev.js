export const URL = 'mongodb+srv://JUN:hyeok0560@cluster0.iy6ss.mongodb.net/?retryWrites=true&w=majority';
